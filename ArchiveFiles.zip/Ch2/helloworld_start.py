#
# Example file for HelloWorld
#


def main():
    print("Hello World!!!!!")
    f = "Welcome to my python tut"
    print(f)

if __name__ == "__main__":
    main()